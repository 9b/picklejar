from distutils.core import setup

setup(
	name='picklejar',
	version='1.0',
	description='Python library to manage/save/restore pickles',
	author='Brandon Dixon',
	author_email='brandon@9bplus.com',
	url='http://blog.9bplus.com',
	py_modules=['picklejar'],
)